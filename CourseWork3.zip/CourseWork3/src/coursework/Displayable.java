package coursework;

import java.awt.Graphics;

public interface Displayable
{
   public void getDisplayable(Graphics g);
}