package coursework;

import java.util.List;
 
public interface DisplayHost
{
   public List<Displayable> getListOfDisplayables();
}