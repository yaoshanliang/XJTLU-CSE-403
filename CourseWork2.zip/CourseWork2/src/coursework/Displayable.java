package coursework;

import java.awt.image.BufferedImage;
 
public interface Displayable
{
   public BufferedImage getDisplayable();
}