package coursework;

 
public interface Writeable
{
   public void saveToDisk();
}