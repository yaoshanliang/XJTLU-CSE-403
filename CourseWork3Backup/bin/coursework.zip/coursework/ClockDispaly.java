package coursework;

import java.awt.Color;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.RenderingHints;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.time.Clock;
import java.time.LocalTime;
import java.awt.event.*;
import javax.imageio.ImageIO;
import javax.swing.JPanel;

public class ClockDispaly extends JPanel implements ActionListener {

    private static final long serialVersionUID = 1L;

    private Clock clock;
    private final int x, y;
    private final int width, height;
    private final Image myImage;
    private String city;
    
    public ClockDispaly(BufferedImage icon, int x, int y, int w, int h, Clock clock, String city) {
        super();
        this.clock = clock;
        this.setLocation(x, y);
        this.setSize(w, h);

        // this.myImage = readImage(icon);
        this.myImage = icon;
        this.setBackground(Color.BLACK);
        this.x = x;
        this.y = y;
        this.width = w;
        this.height = h;
        this.city = city;
    }

    public void actionPerformed(ActionEvent e) {
        repaint();
    }
    @Override
    public int getX() {
        return x;
    }

    @Override
    public int getY() {
        return y;
    }

    @Override
    public int getWidth() {
        return width;
    }

    @Override
    public int getHeight() {
        return height;

    }
    // public void paint(Graphics g) {
    //     super.paint(g);
    //     Graphics2D g2 = (Graphics2D)g;
    //     g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
    //     FontMetrics fm = g.getFontMetrics();
    //     Font font = new Font("SANS-SERIF", Font.BOLD, 100);
    //     g2.setFont(font);
    //     String str = "00:00:00";
    //     int timeWidth = fm.stringWidth(str);
    //     g2.drawString(LocalTime.now(clock).toString(), this.getWidth() / 2 - timeWidth / 2, 200);
    // }

    public void paintComponent(Graphics g) {
        super.paintComponent(g);
        g.drawImage(myImage, 0, 0, 100, 100, this);
        g.setColor(new Color(200, 100, 100));

        Font font = new Font("SANS-SERIF", Font.BOLD, 50);
        g.setFont(font);

        g.drawString(this.city, 200, 80);

        Font ClockFont = new Font("SANS-SERIF", Font.BOLD, 100);
        g.setFont(ClockFont);
        FontMetrics fm = g.getFontMetrics();
        String str = "00:00:00";
        int stringWidth = fm.stringWidth(str);
        
        // System.out.print(LocalTime.now(clock).toString());
        
        System.out.print(LocalTime.now().withNano(0));

        g.drawString(LocalTime.now().withNano(0).toString(), this.getWidth() / 2 - stringWidth / 2, 200);
    }

    public static BufferedImage readImage(String filename){
        BufferedImage image = null;
        try {
                image = ImageIO.read(new File(filename));

        } catch (IOException e) {
                e.printStackTrace();
        }
        return image;
    } 
    

}